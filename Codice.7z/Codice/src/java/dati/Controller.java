/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dati;

/**
 *
 * @author Andrei
 */
public class Controller {
    private GestoreDatabase db;
    private DatiUtente[] ultimaRicerca;

    public Controller() {
        this.db = new GestoreDatabase();
    }
    
    public DatiUtente[] ricerca(UtenteDaRicercare ut) {
        DatiUtente[] ricerca;
        if(ut !=null) {
            ricerca = db.ricerca(ut.getUser_name(),ut.getPwd(),ut.getName(),ut.getEmail());
        } else {
            ricerca = new DatiUtente[0];
        }
        this.ultimaRicerca = ricerca;
        return ricerca;
    }
    
    public DatiUtente[] getAllUsers() {
        this.ultimaRicerca = db.getAllUsers();
        return this.ultimaRicerca;
    }
    
    public void modifica(UtenteDaRicercare modifica) {
        db.modifica(ultimaRicerca[Integer.valueOf(modifica.getIndex())], modifica);
    }
    
}
