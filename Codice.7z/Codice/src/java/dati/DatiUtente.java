/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dati;

/**
 *
 * @author Andrei
 */
public class DatiUtente {
    private String user_name = "";
    private String pwd = "";
    private String name = "";
    private String email = "";
    
    private String Problema_user_name = "";
    private String Problema_pwd = "";
    private String Problema_name = "";
    private String Problema_email = "";
    
    private String feedback;

    public DatiUtente(String user_name, String pwd, String name, String email) {
        this.email = email;
        this.user_name = user_name;
        this.pwd = pwd;
        this.name = name;
    }

    public DatiUtente() {
    }

    
    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProblema_user_name() {
        return Problema_user_name;
    }

    public String getProblema_pwd() {
        return Problema_pwd;
    }

    public String getProblema_name() {
        return Problema_name;
    }

    public String getProblema_email() {
        return Problema_email;
    }
    
    
    public boolean controllo() {
        boolean isOk = true;
        this.Problema_email = "";
        this.Problema_name = "";
        this.Problema_pwd = "";
        this.Problema_user_name = "";
        
        if (this.user_name == null || this.user_name.equals("")) {
            isOk = false;
            this.Problema_user_name = "Username mancante";
        }
        if (this.pwd == null || this.pwd.equals("")) {
            isOk = false;
            this.Problema_pwd = "Password mancante";
        }
        if (this.name == null || this.name.equals("")) {
            isOk = false;
            this.Problema_name = "Nome mancante";
        }
        if (this.email == null || this.email.equals("")) {
            isOk = false;
            this.Problema_email = "Email mancante";
        }
        return isOk;
    }
    
    public void reset() {
        this.user_name = "";
        this.pwd = "";
        this.name = "";
        this.email = "";
        this.Problema_user_name = "";
        this.Problema_pwd = "";
        this.Problema_name = "";
        this.Problema_email = "";
    }
    
    public void salvaDati(){
        new GestoreDatabase().addUtente(this);
    }
}
