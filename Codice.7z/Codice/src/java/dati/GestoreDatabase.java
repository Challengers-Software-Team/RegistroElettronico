/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dati;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author Andrei
 */
public class GestoreDatabase {
    private String driver = "com.mysql.jdbc.Driver";
    private String databaseURL = "jdbc:mysql://localhost:3306/test";
    private String user = "root";
    private String password = "";
    
    private Connection c;
    private Statement s;

    public GestoreDatabase() {
        try {
            // carico i driver JDBC di MySQL
            Class.forName(driver);
            
            // ottengo una connessione al database
            c = DriverManager.getConnection(databaseURL, user, password);
            c.setAutoCommit(true);
            
        } catch (ClassNotFoundException ex) {
             //dati.setFeedback(("ERRORE!: non riesco a trovare i driver JDBC di MySQL nel classpath.\n") + ex.getMessage());
        } catch (SQLException ex) {
            //dati.setFeedback(("ERRORE SQL!\n") + showSQLException(ex));
        }
    }
    
    // Questo metodo mostra le eccezioni SQL eventualmente generate
    private static String showSQLException(java.sql.SQLException e) {
        String error = "";
        SQLException next = e;
        while (next != null) {
            error += (next.getMessage());
            error += ("Error Code: " + next.getErrorCode());
            error += ("SQL State: " + next.getSQLState());
            next = next.getNextException();
        }
        return error;
    }
    
    public void addUtente(DatiUtente dati) {
        try {
            s = c.createStatement();
            String query= "INSERT INTO userinfo (user_id,pwd,name,email) "
                    + "VALUES('"+ dati.getUser_name() + "','" + dati.getPwd() + "','" + dati.getName() + "','" + dati.getEmail() + "')";
            s.executeUpdate(query);
        } catch (SQLException e) {
           showSQLException(e);
        }  finally {
            try { if (s!=null) s.close (); } catch (SQLException e) { dati.setFeedback(dati.getFeedback() + showSQLException(e)); }
            try { if (c!=null) c.close (); } catch (SQLException e) { dati.setFeedback(dati.getFeedback() + showSQLException(e)); }
        }
    }
    
    public DatiUtente[] getAllUsers() {
        Statement s = null;
        ResultSet rs = null;
        
        try {      
            s = c.createStatement();
            rs = s.executeQuery("SELECT * FROM userinfo;");
            
            Vector utenti = new Vector();
            DatiUtente ur;
            String user_name, pwd, name, email;
            while (rs.next()) {
                    user_name = rs.getString("user_id");
                    pwd = rs.getString("pwd");
                    name = rs.getString("name");
                    email = rs.getString("email");
                    ur = new DatiUtente(user_name,pwd,name,email);
                    utenti.add(ur);
            }
            DatiUtente[] risultato=new DatiUtente[utenti.size()];
            for (int i=0; i<risultato.length; i++) {
                risultato[i]=(DatiUtente) utenti.get(i);
            }
            return risultato;
            
        } catch (SQLException ex) {
            return new DatiUtente[0];
        } finally {
            try {
                if (rs!=null) rs.close();
                if (s!=null) s.close();
                if (c!=null) s.close();
            }
            catch (SQLException e) {}
        }
    }
    
    public DatiUtente[] ricerca(String userDaTrovare, String pwdDaTrovare, String nomeDaTrovare, String emailDaTrovare) {
        Statement s = null;
        ResultSet rs = null;
                
        try {
            userDaTrovare = userDaTrovare.toUpperCase();
            s = c.createStatement();
            rs = s.executeQuery("SELECT * FROM userinfo WHERE " +
                    "UPPER(name) LIKE '"+nomeDaTrovare+"%' AND " +
                    "UPPER(pwd) LIKE '"+pwdDaTrovare+"%' AND " +
                    "UPPER(email) LIKE '"+emailDaTrovare+"%' AND " +
                    "UPPER(user_id) LIKE '"+userDaTrovare+"%';");

            Vector utenti= new Vector();
            DatiUtente ur;
            String user_name, pwd, name, email;
            while (rs.next()) {
                user_name = rs.getString("user_id");
                pwd = rs.getString("pwd");
                name = rs.getString("name");
                email = rs.getString("email");
                ur = new DatiUtente(user_name,pwd,name,email);
                utenti.add(ur);
            }
            DatiUtente[] risultato=new DatiUtente[utenti.size()];
            for (int i=0; i<risultato.length; i++) {
                risultato[i]=(DatiUtente) utenti.get(i);
            }
            return risultato;
        }
        catch (SQLException e) {
            showSQLException(e);
            return new DatiUtente[0];
        }
        finally {
            try {
                if (rs!=null) rs.close();
                if (s!=null) s.close();
                if (c!=null) s.close();
            }
            catch (SQLException e) {}
        }
    }
    
    public void modifica(DatiUtente utente, UtenteDaRicercare modifica) {
        String query= "UPDATE userinfo SET "
                + "name = '"+ modifica.getName()+
                "', user_id= '"+ modifica.getUser_name()+
                "', email = '"+ modifica.getEmail()+
                "', pwd = '"+ modifica.getPwd()+
                "' WHERE name = '"+ utente.getName()+
                "' AND user_id = '"+ utente.getUser_name()+
                "' AND email = '"+ utente.getEmail()+
                "' AND pwd = '"+ utente.getPwd()+"';";
        Statement s=null; 
        try {
            s = c.createStatement();
            s.executeUpdate(query);
        }
        catch (SQLException e) {
        }
        finally {
            try { if (s!=null) s.close (); } catch (SQLException e) {}
        }            
    }
    
}
